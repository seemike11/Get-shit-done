import { AppShell } from "@/components/AppShell";
import { ReminderStyle } from "@/lib/types";
import { useTasks } from "@/store/tasks";
import { Bell, Moon, Sun, RotateCcw, Smartphone } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const STYLES: { v: ReminderStyle; label: string; desc: string }[] = [
  { v: "gentle", label: "Gentle", desc: "One nudge. That's it." },
  { v: "normal", label: "Normal", desc: "A reasonable poke." },
  { v: "annoying", label: "Annoying", desc: "Won't stop until you act." },
];

export default function Settings() {
  const { settings, updateSettings, resetDemo } = useTasks();
  const [notifState, setNotifState] = useState<NotificationPermission | "unsupported">(
    typeof Notification !== "undefined" ? Notification.permission : "unsupported"
  );

  const askNotif = async () => {
    if (typeof Notification === "undefined") {
      toast.error("This browser doesn't support notifications.");
      return;
    }
    const r = await Notification.requestPermission();
    setNotifState(r);
    if (r === "granted") {
      new Notification("Reminders on", { body: "We'll nudge you at check-in time." });
      toast.success("Reminders on.");
    } else {
      toast.error("Permission denied.");
    }
  };

  return (
    <AppShell title="Settings" subtitle="Tune how the app pushes you">
      <Section title="Reminder style">
        <div className="space-y-2">
          {STYLES.map((s) => (
            <button
              key={s.v}
              onClick={() => updateSettings({ reminderStyle: s.v })}
              className={`w-full text-left p-4 rounded-2xl border-2 tap ${
                settings.reminderStyle === s.v
                  ? "bg-primary/10 border-primary"
                  : "bg-card border-border"
              }`}
            >
              <div className="font-bold">{s.label}</div>
              <div className="text-sm text-muted-foreground">{s.desc}</div>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Daily rhythm">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Morning planning">
            <input
              type="time"
              value={settings.dailyPlanningTime}
              onChange={(e) => updateSettings({ dailyPlanningTime: e.target.value })}
              className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3"
            />
          </Field>
          <Field label="Evening review">
            <input
              type="time"
              value={settings.eveningReviewTime}
              onChange={(e) => updateSettings({ eveningReviewTime: e.target.value })}
              className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3"
            />
          </Field>
        </div>
      </Section>

      <Section title="Notifications">
        <div className="rounded-2xl bg-card border border-border p-4 space-y-3">
          <div className="flex items-center gap-3">
            <Bell className="h-6 w-6 text-primary" />
            <div className="flex-1">
              <div className="font-bold">Browser reminders</div>
              <div className="text-xs text-muted-foreground">
                Status: {notifState === "granted" ? "On" : notifState === "denied" ? "Blocked" : notifState === "unsupported" ? "Not supported" : "Off"}
              </div>
            </div>
            {notifState !== "granted" && notifState !== "unsupported" && (
              <button onClick={askNotif} className="px-4 h-10 rounded-xl bg-primary text-primary-foreground text-sm font-bold tap">
                Turn on
              </button>
            )}
          </div>
          <div className="rounded-xl bg-secondary/60 p-3 text-sm leading-snug">
            <div className="flex items-center gap-2 font-semibold mb-1">
              <Smartphone className="h-4 w-4" /> iPhone setup
            </div>
            <ol className="list-decimal pl-5 space-y-1 text-muted-foreground">
              <li>Open this site in Safari.</li>
              <li>Tap Share → <b>Add to Home Screen</b>.</li>
              <li>Open it from your home screen, then come back here and tap "Turn on".</li>
            </ol>
            <p className="mt-2 text-xs text-muted-foreground">
              Apple requires installing the app first before Safari will allow notifications. Until then, you'll still see overdue badges and in-app reminders.
            </p>
          </div>
        </div>
      </Section>

      <Section title="Theme">
        <div className="grid grid-cols-2 gap-2 bg-card border-2 border-border rounded-2xl p-1">
          <button
            onClick={() => updateSettings({ theme: "dark" })}
            className={`h-12 rounded-xl flex items-center justify-center gap-2 font-semibold tap ${
              settings.theme === "dark" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
            }`}
          >
            <Moon className="h-4 w-4" /> Dark
          </button>
          <button
            onClick={() => updateSettings({ theme: "light" })}
            className={`h-12 rounded-xl flex items-center justify-center gap-2 font-semibold tap ${
              settings.theme === "light" ? "bg-primary text-primary-foreground" : "text-muted-foreground"
            }`}
          >
            <Sun className="h-4 w-4" /> Light
          </button>
        </div>
      </Section>

      <Section title="Danger zone">
        <button
          onClick={() => {
            if (!confirm("Reset everything to demo data?")) return;
            resetDemo();
            toast("Demo data restored.");
          }}
          className="w-full h-12 rounded-xl bg-secondary text-destructive font-semibold flex items-center justify-center gap-2 tap"
        >
          <RotateCcw className="h-4 w-4" /> Reset demo data
        </button>
      </Section>

      <p className="text-center text-xs text-muted-foreground mt-8">
        Tip: Add this to your iPhone Home Screen for the app feel.
      </p>
    </AppShell>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6">
      <h3 className="font-display font-bold uppercase tracking-wider text-xs text-muted-foreground mb-2 px-1">
        {title}
      </h3>
      {children}
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-semibold text-muted-foreground mb-1 px-1">{label}</div>
      {children}
    </div>
  );
}
