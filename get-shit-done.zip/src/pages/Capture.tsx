import { AppShell } from "@/components/AppShell";
import { useTasks } from "@/store/tasks";
import { Mic } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

const EXAMPLES = [
  "Tomorrow remind me to call the lawyer about the PennDOT letter",
  "Fix truck exhaust this weekend",
  "Pick up tailpipe and hangers Saturday morning",
  "Pay electric bill today",
];

export default function Capture() {
  const [text, setText] = useState("");
  const { addFromQuickCapture } = useTasks();
  const navigate = useNavigate();

  const submit = () => {
    const v = text.trim();
    if (!v) return;
    const t = addFromQuickCapture(v);
    toast.success(`Sorted into ${t.category}`);
    setText("");
    navigate("/");
  };

  return (
    <AppShell title="Quick capture" subtitle="Talk or type. We'll sort it." back>
      <label htmlFor="capture" className="sr-only">Task</label>
      <textarea
        id="capture"
        autoFocus
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Say or type what you need to get done…"
        rows={6}
        className="w-full rounded-2xl bg-card text-foreground placeholder:text-muted-foreground border-2 border-border focus:border-primary outline-none p-4 text-lg leading-snug shadow-card resize-none"
      />

      <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
        <Mic className="h-4 w-4" />
        Tap the mic on your iPhone keyboard to dictate.
      </div>

      <button
        onClick={submit}
        disabled={!text.trim()}
        className="mt-5 w-full h-14 rounded-2xl bg-primary text-primary-foreground font-bold text-lg tap disabled:opacity-40"
      >
        Add & Sort
      </button>

      <div className="mt-8">
        <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-3">
          Examples that work
        </h3>
        <div className="space-y-2">
          {EXAMPLES.map((e) => (
            <button
              key={e}
              onClick={() => setText(e)}
              className="w-full text-left p-3 rounded-xl bg-card border border-border text-sm tap hover:border-primary"
            >
              "{e}"
            </button>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
