import { AppShell } from "@/components/AppShell";
import { NextBest } from "@/components/NextBest";
import { TaskRow } from "@/components/TaskRow";
import { useTasks } from "@/store/tasks";
import { bucketOf, isOverdue } from "@/lib/utils-task";
import { useMemo, useState } from "react";
import { Bell, BellOff } from "lucide-react";
import { toast } from "sonner";

const BUCKETS: { key: ReturnType<typeof bucketOf>; label: string; color: string }[] = [
  { key: "urgent", label: "Urgent", color: "text-urgent" },
  { key: "today", label: "Today", color: "text-primary" },
  { key: "later", label: "Later", color: "text-normal" },
  { key: "waiting", label: "Waiting", color: "text-waiting" },
  { key: "done", label: "Done", color: "text-done" },
];

export default function Today() {
  const { tasks } = useTasks();
  const [notifState, setNotifState] = useState<NotificationPermission | "unsupported">(
    typeof Notification !== "undefined" ? Notification.permission : "unsupported"
  );

  const grouped = useMemo(() => {
    const map: Record<string, typeof tasks> = { urgent: [], today: [], later: [], waiting: [], done: [] };
    for (const t of tasks) map[bucketOf(t)].push(t);
    return map;
  }, [tasks]);

  const overdueCount = tasks.filter(isOverdue).length;
  const today = new Date().toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });

  const askNotif = async () => {
    if (typeof Notification === "undefined") return;
    const r = await Notification.requestPermission();
    setNotifState(r);
    if (r === "granted") {
      toast.success("Reminders are on.");
      new Notification("Get Shit Done", { body: "You'll get nudges from here." });
    }
  };

  return (
    <AppShell
      title="Today"
      subtitle={today}
      right={
        notifState === "default" ? (
          <button onClick={askNotif} aria-label="Enable reminders" className="h-10 w-10 rounded-full bg-secondary flex items-center justify-center tap">
            <BellOff className="h-5 w-5" />
          </button>
        ) : notifState === "granted" ? (
          <div className="h-10 w-10 rounded-full bg-primary/15 text-primary flex items-center justify-center" aria-label="Reminders on">
            <Bell className="h-5 w-5" />
          </div>
        ) : null
      }
    >
      {overdueCount > 0 && (
        <div className="mb-4 rounded-2xl px-4 py-3 bg-urgent/15 border border-urgent/40 text-sm font-semibold text-urgent">
          {overdueCount} task{overdueCount > 1 ? "s" : ""} overdue. Knock one out first.
        </div>
      )}

      <NextBest />

      <div className="mt-6 space-y-6">
        {BUCKETS.map((b) => {
          const items = grouped[b.key] ?? [];
          if (!items.length) return null;
          return (
            <section key={b.key}>
              <div className="flex items-baseline justify-between mb-2 px-1">
                <h3 className={`font-display font-bold uppercase tracking-wider text-xs ${b.color}`}>
                  {b.label}
                </h3>
                <span className="text-xs text-muted-foreground">{items.length}</span>
              </div>
              <div className="space-y-2">
                {items.map((t) => <TaskRow key={t.id} task={t} />)}
              </div>
            </section>
          );
        })}
      </div>
    </AppShell>
  );
}
