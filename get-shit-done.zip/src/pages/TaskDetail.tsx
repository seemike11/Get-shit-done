import { AppShell } from "@/components/AppShell";
import { useTasks } from "@/store/tasks";
import { useNavigate, useParams } from "react-router-dom";
import { CATEGORIES, Category, Priority, Status } from "@/lib/types";
import { useEffect, useState } from "react";
import { Trash2, Plus, X, Hammer } from "lucide-react";
import { toast } from "sonner";

const PRIOS: Priority[] = ["urgent", "high", "normal"];
const STATUSES: { v: Status; label: string }[] = [
  { v: "open", label: "Open" },
  { v: "snoozed", label: "Snoozed" },
  { v: "waiting", label: "Waiting" },
  { v: "done", label: "Done" },
];

function toLocal(iso?: string) {
  if (!iso) return "";
  const d = new Date(iso);
  const off = d.getTimezoneOffset();
  const local = new Date(d.getTime() - off * 60000);
  return local.toISOString().slice(0, 16);
}
function fromLocal(v: string) {
  return v ? new Date(v).toISOString() : undefined;
}

export default function TaskDetail() {
  const { id } = useParams();
  const { tasks, updateTask, deleteTask, breakItDown } = useTasks();
  const navigate = useNavigate();
  const task = tasks.find((t) => t.id === id);

  const [title, setTitle] = useState("");
  const [notes, setNotes] = useState("");
  const [category, setCategory] = useState<Category>("Random");
  const [priority, setPriority] = useState<Priority>("normal");
  const [status, setStatus] = useState<Status>("open");
  const [dueAt, setDueAt] = useState("");
  const [checkInAt, setCheckInAt] = useState("");
  const [newSub, setNewSub] = useState("");

  useEffect(() => {
    if (!task) return;
    setTitle(task.title);
    setNotes(task.notes ?? "");
    setCategory(task.category);
    setPriority(task.priority);
    setStatus(task.status);
    setDueAt(toLocal(task.dueAt));
    setCheckInAt(toLocal(task.checkInAt));
  }, [task?.id]);

  if (!task) {
    return (
      <AppShell title="Not found" back>
        <p className="text-muted-foreground">That task is gone.</p>
      </AppShell>
    );
  }

  const save = () => {
    updateTask(task.id, {
      title: title.trim() || task.title,
      notes,
      category,
      priority,
      status,
      dueAt: fromLocal(dueAt),
      checkInAt: fromLocal(checkInAt),
    });
    toast.success("Saved.");
    navigate(-1);
  };

  const remove = () => {
    if (!confirm("Delete this task?")) return;
    deleteTask(task.id);
    navigate("/");
  };

  const addSub = () => {
    const v = newSub.trim();
    if (!v) return;
    updateTask(task.id, {
      subtasks: [...task.subtasks, { id: `s-${Date.now()}`, title: v, done: false }],
    });
    setNewSub("");
  };

  const toggleSub = (sid: string) => {
    updateTask(task.id, {
      subtasks: task.subtasks.map((s) => s.id === sid ? { ...s, done: !s.done } : s),
    });
  };

  const removeSub = (sid: string) => {
    updateTask(task.id, { subtasks: task.subtasks.filter((s) => s.id !== sid) });
  };

  return (
    <AppShell title="Task" back>
      <div className="space-y-4">
        <Field label="Title">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3 text-lg font-semibold"
          />
        </Field>

        <Field label="Notes">
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            placeholder="Anything you want to remember…"
            className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3 resize-none"
          />
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Category">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as Category)}
              className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3"
            >
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Priority">
            <div className="grid grid-cols-3 gap-1 bg-card border-2 border-border rounded-xl p-1">
              {PRIOS.map((p) => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={`py-2 rounded-lg text-xs font-bold uppercase tap ${
                    priority === p
                      ? p === "urgent" ? "bg-urgent text-urgent-foreground"
                        : p === "high" ? "bg-high text-high-foreground"
                        : "bg-normal text-normal-foreground"
                      : "text-muted-foreground"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Due">
            <input
              type="datetime-local"
              value={dueAt}
              onChange={(e) => setDueAt(e.target.value)}
              className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3 text-sm"
            />
          </Field>
          <Field label="Check-in">
            <input
              type="datetime-local"
              value={checkInAt}
              onChange={(e) => setCheckInAt(e.target.value)}
              className="w-full bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3 text-sm"
            />
          </Field>
        </div>

        <Field label="Status">
          <div className="grid grid-cols-4 gap-1 bg-card border-2 border-border rounded-xl p-1">
            {STATUSES.map((s) => (
              <button
                key={s.v}
                onClick={() => setStatus(s.v)}
                className={`py-2 rounded-lg text-xs font-bold tap ${
                  status === s.v ? "bg-primary text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </Field>

        <Field label="Subtasks">
          <div className="space-y-2">
            {task.subtasks.map((s) => (
              <div key={s.id} className="flex items-center gap-2 bg-card border border-border rounded-xl p-2">
                <button
                  onClick={() => toggleSub(s.id)}
                  className={`h-7 w-7 rounded-md border-2 flex items-center justify-center tap ${
                    s.done ? "bg-done border-done" : "border-border"
                  }`}
                  aria-label="Toggle"
                >
                  {s.done && <span className="text-done-foreground text-xs">✓</span>}
                </button>
                <span className={`flex-1 text-sm ${s.done ? "line-through text-muted-foreground" : ""}`}>{s.title}</span>
                <button onClick={() => removeSub(s.id)} aria-label="Remove" className="text-muted-foreground tap">
                  <X className="h-4 w-4" />
                </button>
              </div>
            ))}
            <div className="flex gap-2">
              <input
                value={newSub}
                onChange={(e) => setNewSub(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addSub()}
                placeholder="Add a step…"
                className="flex-1 bg-card border-2 border-border focus:border-primary outline-none rounded-xl p-3 text-sm"
              />
              <button onClick={addSub} className="h-12 w-12 rounded-xl bg-secondary flex items-center justify-center tap">
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <button
              onClick={() => { breakItDown(task.id); toast("Added 3 steps."); }}
              className="w-full h-11 rounded-xl bg-primary/10 text-primary font-semibold text-sm flex items-center justify-center gap-2 tap"
            >
              <Hammer className="h-4 w-4" /> Break it down for me
            </button>
          </div>
        </Field>

        <div className="flex gap-2 pt-2">
          <button
            onClick={remove}
            className="h-14 px-4 rounded-2xl bg-secondary text-destructive font-semibold flex items-center justify-center gap-2 tap"
          >
            <Trash2 className="h-5 w-5" /> Delete
          </button>
          <button
            onClick={save}
            className="flex-1 h-14 rounded-2xl bg-primary text-primary-foreground font-bold text-lg tap"
          >
            Save
          </button>
        </div>
      </div>
    </AppShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-1.5 px-1">{label}</div>
      {children}
    </div>
  );
}
