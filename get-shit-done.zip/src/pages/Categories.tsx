import { AppShell } from "@/components/AppShell";
import { TaskRow } from "@/components/TaskRow";
import { CATEGORIES, Category } from "@/lib/types";
import { useTasks } from "@/store/tasks";
import { useState } from "react";

export default function Categories() {
  const { tasks } = useTasks();
  const [active, setActive] = useState<Category | "All">("All");

  const filtered = active === "All" ? tasks : tasks.filter((t) => t.category === active);
  const open = filtered.filter((t) => t.status !== "done");
  const done = filtered.filter((t) => t.status === "done");

  return (
    <AppShell title="Categories" subtitle="Everything sorted by bucket">
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
        {(["All", ...CATEGORIES] as const).map((c) => {
          const count = c === "All" ? tasks.length : tasks.filter((t) => t.category === c).length;
          const isActive = active === c;
          return (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`shrink-0 px-4 h-10 rounded-full text-sm font-semibold tap border-2 ${
                isActive
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-card text-foreground border-border"
              }`}
            >
              {c} <span className="opacity-60 ml-1">{count}</span>
            </button>
          );
        })}
      </div>

      <div className="mt-4 space-y-2">
        {open.length === 0 && done.length === 0 && (
          <p className="text-muted-foreground text-center py-12">Nothing here yet.</p>
        )}
        {open.map((t) => <TaskRow key={t.id} task={t} />)}
      </div>

      {done.length > 0 && (
        <>
          <h3 className="font-display font-bold uppercase tracking-wider text-xs text-done mt-6 mb-2 px-1">Done</h3>
          <div className="space-y-2">
            {done.map((t) => <TaskRow key={t.id} task={t} />)}
          </div>
        </>
      )}
    </AppShell>
  );
}
