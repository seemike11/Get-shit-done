export type Priority = "urgent" | "high" | "normal";
export type Status = "open" | "done" | "snoozed" | "waiting";
export type Category =
  | "Legal / Paperwork"
  | "Truck / Repairs"
  | "Money / Work"
  | "House / Projects"
  | "Family"
  | "Errands"
  | "Calls / Texts"
  | "Health"
  | "Random";

export const CATEGORIES: Category[] = [
  "Legal / Paperwork",
  "Truck / Repairs",
  "Money / Work",
  "House / Projects",
  "Family",
  "Errands",
  "Calls / Texts",
  "Health",
  "Random",
];

export interface Subtask {
  id: string;
  title: string;
  done: boolean;
}

export interface Task {
  id: string;
  title: string;
  notes?: string;
  category: Category;
  priority: Priority;
  status: Status;
  dueAt?: string;          // ISO
  checkInAt?: string;      // ISO
  createdAt: string;
  completedAt?: string;
  subtasks: Subtask[];
  raw?: string;
}

export type ReminderStyle = "gentle" | "normal" | "annoying";

export interface Settings {
  reminderStyle: ReminderStyle;
  dailyPlanningTime: string;   // "07:30"
  eveningReviewTime: string;   // "20:00"
  theme: "dark" | "light";
}

export const DEFAULT_SETTINGS: Settings = {
  reminderStyle: "normal",
  dailyPlanningTime: "07:30",
  eveningReviewTime: "20:00",
  theme: "dark",
};
