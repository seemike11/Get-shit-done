import { Task } from "@/lib/types";

export function isOverdue(t: Task): boolean {
  return !!t.dueAt && new Date(t.dueAt).getTime() < Date.now() && t.status === "open";
}

export function bucketOf(t: Task): "urgent" | "today" | "later" | "waiting" | "done" {
  if (t.status === "done") return "done";
  if (t.status === "waiting") return "waiting";
  if (t.priority === "urgent" || isOverdue(t)) return "urgent";
  if (t.dueAt) {
    const d = new Date(t.dueAt);
    const now = new Date();
    if (d.toDateString() === now.toDateString()) return "today";
  }
  return "later";
}

export function formatWhen(iso?: string): string {
  if (!iso) return "No date";
  const d = new Date(iso);
  const now = new Date();
  const same = d.toDateString() === now.toDateString();
  const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1);
  const isTomorrow = d.toDateString() === tomorrow.toDateString();
  const time = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (same) return `Today · ${time}`;
  if (isTomorrow) return `Tomorrow · ${time}`;
  const diffDays = Math.round((d.getTime() - now.getTime()) / 86400000);
  if (diffDays > 0 && diffDays < 7) {
    return d.toLocaleDateString([], { weekday: "short" }) + " · " + time;
  }
  if (diffDays < 0) return `Overdue · ${d.toLocaleDateString()}`;
  return d.toLocaleDateString([], { month: "short", day: "numeric" });
}

export function relativeFromNow(iso?: string): string {
  if (!iso) return "";
  const diff = new Date(iso).getTime() - Date.now();
  const abs = Math.abs(diff);
  const mins = Math.round(abs / 60000);
  if (mins < 60) return diff < 0 ? `${mins}m ago` : `in ${mins}m`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return diff < 0 ? `${hrs}h ago` : `in ${hrs}h`;
  const days = Math.round(hrs / 24);
  return diff < 0 ? `${days}d ago` : `in ${days}d`;
}
