import { DEFAULT_SETTINGS, Settings, Task } from "./types";

const TASKS_KEY = "gsd.tasks.v1";
const SETTINGS_KEY = "gsd.settings.v1";
const SEEDED_KEY = "gsd.seeded.v1";

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(TASKS_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as Task[];
  } catch {
    return [];
  }
}

export function saveTasks(tasks: Task[]) {
  localStorage.setItem(TASKS_KEY, JSON.stringify(tasks));
}

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: Settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

export function hasSeeded(): boolean {
  return localStorage.getItem(SEEDED_KEY) === "1";
}

export function markSeeded() {
  localStorage.setItem(SEEDED_KEY, "1");
}

export function clearAll() {
  localStorage.removeItem(TASKS_KEY);
  localStorage.removeItem(SEEDED_KEY);
}
