import { Category, Priority, Task } from "./types";

const CATEGORY_KEYWORDS: Record<string, Category> = {
  // Legal
  lawyer: "Legal / Paperwork",
  attorney: "Legal / Paperwork",
  court: "Legal / Paperwork",
  penndot: "Legal / Paperwork",
  dmv: "Legal / Paperwork",
  license: "Legal / Paperwork",
  letter: "Legal / Paperwork",
  certified: "Legal / Paperwork",
  paperwork: "Legal / Paperwork",
  form: "Legal / Paperwork",
  // Truck
  truck: "Truck / Repairs",
  f250: "Truck / Repairs",
  "f-250": "Truck / Repairs",
  exhaust: "Truck / Repairs",
  catalytic: "Truck / Repairs",
  tailpipe: "Truck / Repairs",
  hanger: "Truck / Repairs",
  brake: "Truck / Repairs",
  tire: "Truck / Repairs",
  oil: "Truck / Repairs",
  engine: "Truck / Repairs",
  repair: "Truck / Repairs",
  // Money
  bill: "Money / Work",
  invoice: "Money / Work",
  pay: "Money / Work",
  paycheck: "Money / Work",
  bank: "Money / Work",
  client: "Money / Work",
  job: "Money / Work",
  work: "Money / Work",
  // House
  house: "House / Projects",
  well: "House / Projects",
  pump: "House / Projects",
  roof: "House / Projects",
  yard: "House / Projects",
  fix: "House / Projects",
  build: "House / Projects",
  paint: "House / Projects",
  // Family
  wife: "Family",
  husband: "Family",
  kid: "Family",
  son: "Family",
  daughter: "Family",
  mom: "Family",
  dad: "Family",
  family: "Family",
  // Errands
  store: "Errands",
  pickup: "Errands",
  "pick up": "Errands",
  grocery: "Errands",
  walmart: "Errands",
  // Calls
  call: "Calls / Texts",
  text: "Calls / Texts",
  email: "Calls / Texts",
  message: "Calls / Texts",
  // Health
  doctor: "Health",
  dentist: "Health",
  appointment: "Health",
  med: "Health",
  prescription: "Health",
  gym: "Health",
};

const URGENT_WORDS = [
  "court", "license", "lawyer", "deadline", "bill due", "appointment",
  "emergency", "asap", "urgent", "today", "tonight", "now",
];

const HIGH_WORDS = ["truck", "exhaust", "brake", "money", "bill", "lawyer", "penndot", "letter"];

export interface ParseResult {
  title: string;
  category: Category;
  priority: Priority;
  dueAt?: Date;
  checkInAt?: Date;
}

function nextWeekday(target: number, base = new Date()): Date {
  const d = new Date(base);
  const diff = (target - d.getDay() + 7) % 7 || 7;
  d.setDate(d.getDate() + diff);
  d.setHours(9, 0, 0, 0);
  return d;
}

function detectDate(input: string): Date | undefined {
  const s = input.toLowerCase();
  const now = new Date();
  const at = (h: number, m = 0, d = new Date()) => {
    const x = new Date(d);
    x.setHours(h, m, 0, 0);
    return x;
  };
  if (/\btonight\b/.test(s)) return at(20, 0);
  if (/\bthis morning\b/.test(s)) return at(9, 0);
  if (/\bthis afternoon\b/.test(s)) return at(14, 0);
  if (/\btoday\b/.test(s)) return at(Math.max(now.getHours() + 2, 17), 0);
  if (/\btomorrow\b/.test(s)) {
    const t = new Date(now);
    t.setDate(t.getDate() + 1);
    return at(9, 0, t);
  }
  if (/\bthis weekend\b|\bweekend\b/.test(s)) return nextWeekday(6, now); // Saturday
  if (/\bnext week\b/.test(s)) {
    const d = new Date(now);
    d.setDate(d.getDate() + 7);
    d.setHours(9, 0, 0, 0);
    return d;
  }
  if (/\bmonday\b/.test(s)) return nextWeekday(1);
  if (/\btuesday\b/.test(s)) return nextWeekday(2);
  if (/\bwednesday\b/.test(s)) return nextWeekday(3);
  if (/\bthursday\b/.test(s)) return nextWeekday(4);
  if (/\bfriday\b/.test(s)) return nextWeekday(5);
  if (/\bsaturday\b/.test(s)) return nextWeekday(6);
  if (/\bsunday\b/.test(s)) return nextWeekday(0);
  return undefined;
}

function detectCategory(input: string): Category {
  const s = input.toLowerCase();
  for (const key of Object.keys(CATEGORY_KEYWORDS)) {
    if (s.includes(key)) return CATEGORY_KEYWORDS[key];
  }
  return "Random";
}

function detectPriority(input: string, dueAt?: Date, category?: Category): Priority {
  const s = input.toLowerCase();
  if (URGENT_WORDS.some((w) => s.includes(w))) return "urgent";
  if (dueAt) {
    const hours = (dueAt.getTime() - Date.now()) / 36e5;
    if (hours <= 36) return "high";
  }
  if (HIGH_WORDS.some((w) => s.includes(w))) return "high";
  if (category === "Legal / Paperwork" || category === "Money / Work") return "high";
  return "normal";
}

function cleanTitle(input: string): string {
  return input
    .replace(/\b(remind me to|please|pls|i need to|i gotta|gotta|need to|tomorrow|tonight|today|this weekend|next week|this morning|this afternoon)\b/gi, "")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/^./, (c) => c.toUpperCase());
}

export function parseQuickCapture(raw: string): ParseResult {
  const dueAt = detectDate(raw);
  const category = detectCategory(raw);
  const priority = detectPriority(raw, dueAt, category);
  const title = cleanTitle(raw) || raw.trim();

  // Check-in time
  let checkInAt: Date | undefined;
  const now = new Date();
  if (priority === "urgent") {
    checkInAt = new Date(now.getTime() + 60 * 60 * 1000); // 1h
  } else if (dueAt) {
    const isToday = dueAt.toDateString() === now.toDateString();
    const isTomorrow = dueAt.toDateString() === new Date(now.getTime() + 86400000).toDateString();
    if (isToday) {
      checkInAt = new Date(now.getTime() + 3 * 60 * 60 * 1000);
    } else if (isTomorrow) {
      checkInAt = new Date(dueAt);
      checkInAt.setHours(8, 0, 0, 0);
    } else if (dueAt.getDay() === 6 || dueAt.getDay() === 0) {
      checkInAt = new Date(dueAt);
      checkInAt.setHours(9, 0, 0, 0);
    } else {
      checkInAt = new Date(dueAt);
      checkInAt.setHours(8, 0, 0, 0);
    }
  } else {
    // Next daily planning time
    const c = new Date(now);
    c.setDate(c.getDate() + 1);
    c.setHours(7, 30, 0, 0);
    checkInAt = c;
  }

  return { title, category, priority, dueAt, checkInAt };
}

export function breakDown(task: Task): string[] {
  const t = task.title.toLowerCase();
  if (t.includes("call") || task.category === "Calls / Texts") {
    return [
      `Find the right phone number for: ${task.title}`,
      `Write down 3 questions to ask`,
      `Make the call and take notes`,
    ];
  }
  if (task.category === "Truck / Repairs") {
    return [
      `Look up the part numbers / specs needed`,
      `Order or pick up parts`,
      `Block off time and do the repair`,
    ];
  }
  if (task.category === "Legal / Paperwork") {
    return [
      `Gather every document related to this`,
      `Read it once and underline what matters`,
      `Take the next concrete action (call, mail, file)`,
    ];
  }
  if (task.category === "Money / Work") {
    return [
      `Confirm exact amount and deadline`,
      `Decide how it gets paid / done`,
      `Do it and mark it paid`,
    ];
  }
  return [
    `Spend 5 minutes deciding the very first step`,
    `Do that first step right now`,
    `Schedule the next step before stopping`,
  ];
}
