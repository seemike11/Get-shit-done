import { Task } from "./types";
import { parseQuickCapture } from "./parser";

const seeds: { raw: string; notes?: string }[] = [
  { raw: "today call lawyer about certified satisfaction letter", notes: "Need confirmation he received it." },
  { raw: "fix F-250 exhaust connection this weekend before catalytic converter goes", notes: "Driver-side mid-pipe leak." },
  { raw: "order tailpipe and hangers for truck", notes: "Check RockAuto first." },
  { raw: "tomorrow check PennDOT restoration requirements", notes: "Bring driver history printout." },
  { raw: "price shallow well pump parts this weekend", notes: "Foot valve, pressure switch, gauge." },
];

export function buildDemoTasks(): Task[] {
  return seeds.map((s, i) => {
    const p = parseQuickCapture(s.raw);
    const t: Task = {
      id: `seed-${i}-${Date.now()}`,
      title: p.title,
      notes: s.notes,
      category: p.category,
      priority: p.priority,
      status: "open",
      dueAt: p.dueAt?.toISOString(),
      checkInAt: p.checkInAt?.toISOString(),
      createdAt: new Date().toISOString(),
      subtasks: [],
      raw: s.raw,
    };
    return t;
  });
}
