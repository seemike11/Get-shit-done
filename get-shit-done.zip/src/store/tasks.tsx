import { createContext, ReactNode, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Settings, Task } from "@/lib/types";
import { hasSeeded, loadSettings, loadTasks, markSeeded, saveSettings, saveTasks, clearAll } from "@/lib/storage";
import { buildDemoTasks } from "@/lib/demo";
import { breakDown, parseQuickCapture } from "@/lib/parser";

interface Ctx {
  tasks: Task[];
  settings: Settings;
  addFromQuickCapture: (raw: string) => Task;
  updateTask: (id: string, patch: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  markDone: (id: string) => void;
  snooze: (id: string, hours?: number) => void;
  cantDoNow: (id: string) => void;
  breakItDown: (id: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  resetDemo: () => void;
  nextBest: Task | undefined;
}

const TaskCtx = createContext<Ctx | null>(null);

export function TaskProvider({ children }: { children: ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [settings, setSettings] = useState<Settings>(loadSettings());

  useEffect(() => {
    if (!hasSeeded()) {
      const demo = buildDemoTasks();
      setTasks(demo);
      saveTasks(demo);
      markSeeded();
    } else {
      setTasks(loadTasks());
    }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", settings.theme === "dark");
  }, [settings.theme]);

  const persist = (next: Task[]) => {
    setTasks(next);
    saveTasks(next);
  };

  const addFromQuickCapture = useCallback((raw: string): Task => {
    const p = parseQuickCapture(raw);
    const t: Task = {
      id: `t-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      title: p.title,
      category: p.category,
      priority: p.priority,
      status: "open",
      dueAt: p.dueAt?.toISOString(),
      checkInAt: p.checkInAt?.toISOString(),
      createdAt: new Date().toISOString(),
      subtasks: [],
      raw,
    };
    setTasks((cur) => {
      const next = [t, ...cur];
      saveTasks(next);
      return next;
    });
    return t;
  }, []);

  const updateTask = useCallback((id: string, patch: Partial<Task>) => {
    setTasks((cur) => {
      const next = cur.map((t) => (t.id === id ? { ...t, ...patch } : t));
      saveTasks(next);
      return next;
    });
  }, []);

  const deleteTask = useCallback((id: string) => {
    setTasks((cur) => {
      const next = cur.filter((t) => t.id !== id);
      saveTasks(next);
      return next;
    });
  }, []);

  const markDone = useCallback((id: string) => {
    updateTask(id, { status: "done", completedAt: new Date().toISOString() });
  }, [updateTask]);

  const snooze = useCallback((id: string, hours = 3) => {
    const checkInAt = new Date(Date.now() + hours * 3600_000).toISOString();
    updateTask(id, { status: "snoozed", checkInAt });
  }, [updateTask]);

  const cantDoNow = useCallback((id: string) => {
    updateTask(id, { status: "waiting" });
  }, [updateTask]);

  const breakItDown = useCallback((id: string) => {
    setTasks((cur) => {
      const next = cur.map((t) => {
        if (t.id !== id) return t;
        const subs = breakDown(t).map((title, i) => ({
          id: `s-${id}-${i}-${Date.now()}`,
          title,
          done: false,
        }));
        return { ...t, subtasks: [...t.subtasks, ...subs] };
      });
      saveTasks(next);
      return next;
    });
  }, []);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((cur) => {
      const next = { ...cur, ...patch };
      saveSettings(next);
      return next;
    });
  }, []);

  const resetDemo = useCallback(() => {
    clearAll();
    const demo = buildDemoTasks();
    persist(demo);
    markSeeded();
  }, []);

  const nextBest = useMemo(() => pickNextBest(tasks), [tasks]);

  const value: Ctx = {
    tasks, settings, addFromQuickCapture, updateTask, deleteTask,
    markDone, snooze, cantDoNow, breakItDown, updateSettings, resetDemo, nextBest,
  };

  return <TaskCtx.Provider value={value}>{children}</TaskCtx.Provider>;
}

export function useTasks() {
  const c = useContext(TaskCtx);
  if (!c) throw new Error("useTasks must be inside TaskProvider");
  return c;
}

function priorityWeight(p: Task["priority"]) {
  return p === "urgent" ? 3 : p === "high" ? 2 : 1;
}

function pickNextBest(tasks: Task[]): Task | undefined {
  const open = tasks.filter((t) => t.status === "open");
  if (!open.length) return undefined;
  const now = Date.now();
  return [...open].sort((a, b) => {
    const aOver = a.dueAt ? new Date(a.dueAt).getTime() < now : false;
    const bOver = b.dueAt ? new Date(b.dueAt).getTime() < now : false;
    if (aOver !== bOver) return aOver ? -1 : 1;
    const pw = priorityWeight(b.priority) - priorityWeight(a.priority);
    if (pw !== 0) return pw;
    const aDue = a.dueAt ? new Date(a.dueAt).getTime() : Infinity;
    const bDue = b.dueAt ? new Date(b.dueAt).getTime() : Infinity;
    return aDue - bDue;
  })[0];
}
