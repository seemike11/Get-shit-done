import { useEffect, useRef } from "react";
import { useTasks } from "@/store/tasks";
import { toast } from "sonner";

/**
 * In-app reminder loop. Checks every minute for tasks whose check-in time
 * has just passed and fires a browser notification (if granted) plus a toast.
 */
export function ReminderRunner() {
  const { tasks, settings } = useTasks();
  const fired = useRef<Set<string>>(new Set());

  useEffect(() => {
    const tick = () => {
      const now = Date.now();
      for (const t of tasks) {
        if (t.status !== "open" && t.status !== "snoozed") continue;
        if (!t.checkInAt) continue;
        const due = new Date(t.checkInAt).getTime();
        const key = `${t.id}:${t.checkInAt}`;
        if (due <= now && !fired.current.has(key)) {
          fired.current.add(key);
          const body =
            settings.reminderStyle === "annoying"
              ? `STILL waiting on you: ${t.title}`
              : settings.reminderStyle === "gentle"
              ? `Quick nudge: ${t.title}`
              : `Time to check in: ${t.title}`;
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            try { new Notification("Get Shit Done", { body, tag: t.id }); } catch {}
          }
          toast(body, { duration: 8000 });
        }
      }
    };
    tick();
    const id = window.setInterval(tick, 60_000);
    return () => window.clearInterval(id);
  }, [tasks, settings.reminderStyle]);

  return null;
}
