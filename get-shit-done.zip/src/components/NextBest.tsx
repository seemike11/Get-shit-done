import { useTasks } from "@/store/tasks";
import { CheckCircle2, Clock, Hammer, MoreHorizontal, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { formatWhen } from "@/lib/utils-task";
import { toast } from "sonner";

export function NextBest() {
  const { nextBest, markDone, snooze, cantDoNow, breakItDown } = useTasks();
  const navigate = useNavigate();

  if (!nextBest) {
    return (
      <div className="relative overflow-hidden rounded-3xl p-8 gradient-hero shadow-card text-center grain">
        <div className="text-5xl mb-3">🌤</div>
        <h2 className="font-display text-3xl font-bold tracking-tight">All clear.</h2>
        <p className="text-muted-foreground mt-2">
          <span className="font-serif-italic text-foreground/80">Nothing</span> on the list. Add the next thing.
        </p>
        <button
          onClick={() => navigate("/capture")}
          className="mt-5 w-full h-13 py-3.5 rounded-2xl gradient-amber text-primary-foreground font-bold tap shadow-pop"
        >
          Add a task
        </button>
      </div>
    );
  }

  const overdue = nextBest.dueAt && new Date(nextBest.dueAt).getTime() < Date.now();

  return (
    <div className="relative overflow-hidden rounded-3xl p-6 gradient-hero shadow-card ring-glow grain">
      <div className="absolute -top-20 -right-16 w-56 h-56 rounded-full opacity-30 gradient-amber blur-2xl" />
      <div className="absolute -bottom-24 -left-16 w-56 h-56 rounded-full opacity-20 blur-2xl" style={{ background: "hsl(275 80% 60%)" }} />

      <div className="relative">
        <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.2em] text-primary">
          <Sparkles className="h-3.5 w-3.5" /> Next best
        </div>

        <h2 className="font-display text-[28px] font-bold mt-3 leading-[1.1] tracking-tight">
          {nextBest.title}
        </h2>

        <div className="flex items-center gap-2 mt-4">
          <span className="px-2.5 py-1 rounded-full bg-background/60 border border-border/60 text-[11px] font-semibold uppercase tracking-wider">
            {nextBest.category}
          </span>
          <span className={`flex items-center gap-1 text-xs ${overdue ? "text-urgent font-bold" : "text-muted-foreground"}`}>
            <Clock className="h-3.5 w-3.5" /> {formatWhen(nextBest.dueAt)}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-5">
          <button
            onClick={() => { markDone(nextBest.id); toast.success("Done. One less thing."); }}
            className="h-14 rounded-2xl bg-done text-done-foreground font-bold flex items-center justify-center gap-2 tap shadow-card"
          >
            <CheckCircle2 className="h-5 w-5" /> Done
          </button>
          <button
            onClick={() => { snooze(nextBest.id, 3); toast("Snoozed 3 hours."); }}
            className="h-14 rounded-2xl bg-secondary text-secondary-foreground font-bold flex items-center justify-center gap-2 tap"
          >
            <Clock className="h-5 w-5" /> Snooze
          </button>
          <button
            onClick={() => { cantDoNow(nextBest.id); toast("Moved to Waiting."); }}
            className="h-12 rounded-xl bg-secondary/60 text-secondary-foreground font-semibold text-sm tap flex items-center justify-center gap-1.5"
          >
            <MoreHorizontal className="h-4 w-4" /> Can't now
          </button>
          <button
            onClick={() => { breakItDown(nextBest.id); toast("Broke it into 3 steps."); navigate(`/task/${nextBest.id}`); }}
            className="h-12 rounded-xl gradient-amber text-primary-foreground font-bold text-sm tap flex items-center justify-center gap-1.5 shadow-pop"
          >
            <Hammer className="h-4 w-4" /> Break it down
          </button>
        </div>
      </div>
    </div>
  );
}
