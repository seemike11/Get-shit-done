import { ReactNode } from "react";
import { BottomNav } from "./BottomNav";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface Props {
  title?: string;
  subtitle?: string;
  back?: boolean;
  right?: ReactNode;
  children: ReactNode;
}

export function AppShell({ title, subtitle, back, right, children }: Props) {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-md flex flex-col min-h-screen">
        {(title || back) && (
          <header className="safe-top px-5 pt-4 pb-3 flex items-start justify-between gap-3">
            <div className="flex items-start gap-3 min-w-0">
              {back && (
                <button
                  onClick={() => navigate(-1)}
                  aria-label="Back"
                  className="mt-1 h-10 w-10 -ml-2 rounded-full flex items-center justify-center bg-secondary tap"
                >
                  <ArrowLeft className="h-5 w-5" />
                </button>
              )}
              <div className="min-w-0">
                {title && <h1 className="font-display text-[34px] font-bold truncate leading-none tracking-tight">{title}</h1>}
                {subtitle && <p className="text-sm text-muted-foreground mt-1.5 font-serif-italic">{subtitle}</p>}
              </div>
            </div>
            {right}
          </header>
        )}
        <main className="flex-1 px-5 pb-32">{children}</main>
        <BottomNav />
      </div>
    </div>
  );
}
