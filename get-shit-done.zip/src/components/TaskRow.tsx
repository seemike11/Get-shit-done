import { Task } from "@/lib/types";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { formatWhen } from "@/lib/utils-task";
import { CheckCircle2, Circle, Clock } from "lucide-react";
import { useTasks } from "@/store/tasks";

const PRIO_BAR: Record<Task["priority"], string> = {
  urgent: "bg-urgent",
  high: "bg-high",
  normal: "bg-normal",
};

const PRIO_TEXT: Record<Task["priority"], string> = {
  urgent: "text-urgent",
  high: "text-high",
  normal: "text-normal",
};

export function TaskRow({ task }: { task: Task }) {
  const { markDone } = useTasks();
  const overdue = task.dueAt && new Date(task.dueAt).getTime() < Date.now() && task.status === "open";
  const done = task.status === "done";
  return (
    <div className="relative flex items-center gap-3 bg-card rounded-2xl p-3 pl-4 shadow-card overflow-hidden">
      <span className={cn("absolute left-0 top-3 bottom-3 w-1 rounded-r-full", PRIO_BAR[task.priority], done && "bg-done/40")} />
      <button
        aria-label={done ? "Completed" : "Mark done"}
        onClick={(e) => { e.preventDefault(); markDone(task.id); }}
        className={cn(
          "shrink-0 h-11 w-11 rounded-full flex items-center justify-center tap transition-colors",
          done ? "bg-done/15" : "bg-secondary hover:bg-secondary/70"
        )}
      >
        {done ? <CheckCircle2 className="h-6 w-6 text-done" /> : <Circle className="h-6 w-6 text-muted-foreground" />}
      </button>
      <Link to={`/task/${task.id}`} className="flex-1 min-w-0 tap">
        <div className="flex items-center gap-2">
          <span className={cn("text-[10px] font-bold uppercase tracking-[0.15em]", PRIO_TEXT[task.priority], done && "text-muted-foreground")}>
            {task.priority}
          </span>
          <span className="text-[11px] text-muted-foreground truncate">· {task.category}</span>
        </div>
        <div className={cn("font-semibold mt-0.5 leading-tight tracking-tight", done && "line-through text-muted-foreground")}>
          {task.title}
        </div>
        <div className={cn("flex items-center gap-1 text-xs mt-1", overdue ? "text-urgent font-semibold" : "text-muted-foreground")}>
          <Clock className="h-3.5 w-3.5" />
          {formatWhen(task.dueAt)}
        </div>
      </Link>
    </div>
  );
}
