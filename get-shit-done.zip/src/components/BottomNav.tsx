import { NavLink } from "react-router-dom";
import { Home, Plus, FolderKanban, Settings as SettingsIcon } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Today", icon: Home },
  { to: "/capture", label: "Add", icon: Plus, primary: true },
  { to: "/categories", label: "Categories", icon: FolderKanban },
  { to: "/settings", label: "Settings", icon: SettingsIcon },
];

export function BottomNav() {
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 safe-bottom pointer-events-none">
      <div className="mx-auto max-w-md px-3 pb-3 pointer-events-auto">
        <div className="glass border border-border/60 rounded-3xl shadow-card grid grid-cols-4 gap-1 px-2 pt-2 pb-2 relative">
          {items.map(({ to, label, icon: Icon, primary }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              className={({ isActive }) =>
                cn(
                  "flex flex-col items-center justify-center gap-1 py-2 rounded-2xl tap transition-colors",
                  primary && "relative -mt-7 gradient-amber text-primary-foreground shadow-pop ring-4 ring-background",
                  !primary && isActive && "text-primary bg-primary/10",
                  !primary && !isActive && "text-muted-foreground hover:text-foreground"
                )
              }
            >
              <Icon className={cn("h-5 w-5", primary && "h-7 w-7")} strokeWidth={2.4} />
              <span className={cn("text-[10px] font-bold tracking-wider uppercase", primary && "text-primary-foreground")}>{label}</span>
            </NavLink>
          ))}
        </div>
      </div>
    </nav>
  );
}
